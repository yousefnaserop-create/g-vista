const WHATSAPP_NUMBER = "201143561211";

document.getElementById("year").textContent = new Date().getFullYear();

// Hide intro after the logo has had time to appear.
window.addEventListener("load", () => {
  window.setTimeout(() => document.getElementById("intro")?.classList.add("hide"), 1500);
});
// Fallback in case the browser's load event is delayed.
window.setTimeout(() => document.getElementById("intro")?.classList.add("hide"), 3500);

// Mobile navigation
const menuToggle = document.getElementById("menuToggle");
const nav = document.getElementById("nav");

menuToggle.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(open));
  menuToggle.textContent = open ? "×" : "☰";
});

nav.querySelectorAll("a").forEach(link => {
  link.addEventListener("click", () => {
    nav.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.textContent = "☰";
  });
});

// Reveal content as it enters the viewport.
const revealItems = document.querySelectorAll(".section-top, .product-card, .story-logo, .story-copy, .contact");
revealItems.forEach(item => item.classList.add("reveal"));

if ("IntersectionObserver" in window) {
  const observer = new IntersectionObserver((entries, currentObserver) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        currentObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  revealItems.forEach(item => observer.observe(item));
} else {
  revealItems.forEach(item => item.classList.add("visible"));
}

// Each product opens WhatsApp with the correct product and displayed price.
document.querySelectorAll(".order-button").forEach(button => {
  button.addEventListener("click", () => {
    const card = button.closest(".product-card");
    const product = card.dataset.product;
    const price = card.dataset.price;
    const message = `أهلاً Gi Vista، عايز أستفسر عن ${product} وسعره المعروض ${price} جنيه. هل متوفر؟`;
    const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
    window.open(url, "_blank", "noopener,noreferrer");
  });
});

// Pointer tilt for desktop. The mug continues to rotate on touch devices using CSS.
const mug = document.querySelector(".mug");
const art = document.querySelector(".hero-art");
if (mug && art && matchMedia("(hover:hover) and (pointer:fine)").matches) {
  art.addEventListener("pointermove", event => {
    const rect = art.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width - 0.5;
    const y = (event.clientY - rect.top) / rect.height - 0.5;
    mug.style.animation = "none";
    mug.style.transform = `rotateY(${x * 25}deg) rotateX(${-y * 10}deg)`;
  });
  art.addEventListener("pointerleave", () => {
    mug.style.transform = "";
    mug.style.animation = "";
  });
}
