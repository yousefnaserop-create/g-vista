const menuToggle = document.getElementById("menuToggle");
const nav = document.getElementById("nav");
const selectionMessage = document.getElementById("selectionMessage");
const toast = document.getElementById("toast");

menuToggle.addEventListener("click", () => {
  const isOpen = nav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.textContent = isOpen ? "×" : "☰";
});

nav.querySelectorAll("a").forEach(link => {
  link.addEventListener("click", () => {
    nav.classList.remove("open");
    menuToggle.textContent = "☰";
    menuToggle.setAttribute("aria-expanded", "false");
  });
});

let toastTimer;
function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2800);
}

document.querySelectorAll(".add-button").forEach(button => {
  button.addEventListener("click", () => {
    const card = button.closest(".product-card");
    const product = card.dataset.product;
    selectionMessage.textContent = `اختارت ${product} — اختيار جميل! تقدر تتواصل معانا لتفاصيل الطلب.`;
    showToast(`تم اختيار ${product}`);
    button.textContent = "✓";
    document.querySelectorAll(".add-button").forEach(other => {
      if (other !== button) other.textContent = "↙";
    });
  });
});

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("visible");
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });
document.querySelectorAll(".reveal").forEach(element => observer.observe(element));

document.getElementById("year").textContent = new Date().getFullYear();

// Replace hello@example.com in index.html with your real email or store contact link.
document.getElementById("contactButton").addEventListener("click", event => {
  const href = event.currentTarget.getAttribute("href");
  if (href.includes("hello@example.com")) {
    event.preventDefault();
    showToast("عدّل hello@example.com في index.html وحط إيميلك الحقيقي.");
  }
});
